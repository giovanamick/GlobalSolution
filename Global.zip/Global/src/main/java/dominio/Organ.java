package dominio;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "organ")
public class Organ {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int organId;

	@Column(length = 50, nullable = false)
	private String organName;

	@JoinColumn(name = "fk_hoto_id", nullable = false)
	private int hotoId;

	@JoinColumn(name = "fk_storage_id", nullable = false)
	private int storageId;

	@JoinColumn(name = "fk_address_id", nullable = false)
	private int addressId;

	public int getOrganId() {
		return organId;
	}

	public void setOrganId(int organId) {
		this.organId = organId;
	}

	public String getOrganName() {
		return organName;
	}

	public void setOrganName(String organName) {
		this.organName = organName;
	}

	public int getHotoId() {
		return hotoId;
	}

	public void setHotoId(int hotoId) {
		this.hotoId = hotoId;
	}

	public int getStorageId() {
		return storageId;
	}

	public void setStorageId(int storageId) {
		this.storageId = storageId;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	@Override
	public int hashCode() {
		return Objects.hash(addressId, hotoId, organId, organName, storageId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Organ other = (Organ) obj;
		return addressId == other.addressId && hotoId == other.hotoId && organId == other.organId
				&& Objects.equals(organName, other.organName) && storageId == other.storageId;
	}

	@Override
	public String toString() {
		return "Organ [organId=" + organId + ", organName=" + organName + ", hotoId=" + hotoId + ", storageId="
				+ storageId + ", addressId=" + addressId + "]";
	}

	public Organ(int organId, String organName, int hotoId, int storageId, int addressId) {
		super();
		this.organId = organId;
		this.organName = organName;
		this.hotoId = hotoId;
		this.storageId = storageId;
		this.addressId = addressId;
	}

	public Organ() {

	}
}
