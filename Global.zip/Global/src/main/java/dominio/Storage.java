package dominio;

import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "storage")
public class Storage {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int storageId;

	@JoinColumn(name = "fk_vegetable_garden_id", nullable = false)
	private int vegetableGardenId;

	public int getStorageId() {
		return storageId;
	}

	public void setStorageId(int storageId) {
		this.storageId = storageId;
	}

	public int getVegetableGardenId() {
		return vegetableGardenId;
	}

	public void setVegetableGardenId(int vegetableGardenId) {
		this.vegetableGardenId = vegetableGardenId;
	}

	@Override
	public int hashCode() {
		return Objects.hash(storageId, vegetableGardenId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Storage other = (Storage) obj;
		return storageId == other.storageId && vegetableGardenId == other.vegetableGardenId;
	}

	@Override
	public String toString() {
		return "Storage [storageId=" + storageId + ", vegetableGardenId=" + vegetableGardenId + "]";
	}

	public Storage(int storageId, int vegetableGardenId) {
		super();
		this.storageId = storageId;
		this.vegetableGardenId = vegetableGardenId;
	}

	public Storage() {

	}
}
