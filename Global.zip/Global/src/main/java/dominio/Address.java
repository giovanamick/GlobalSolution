package dominio;

import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "address")
public class Address {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int addressId;

	@Column(length = 50, nullable = false)
	private String road;

	@Column(length = 50, nullable = false)
	private String neighborhood;

	@Column(length = 50, nullable = false)
	private String city;

	@Column(length = 50, nullable = false)
	private String state;

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getRoad() {
		return road;
	}

	public void setRoad(String road) {
		this.road = road;
	}

	public String getNeighborhood() {
		return neighborhood;
	}

	public void setNeighborhood(String neighborhood) {
		this.neighborhood = neighborhood;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public int hashCode() {
		return Objects.hash(addressId, city, neighborhood, road, state);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		return addressId == other.addressId && Objects.equals(city, other.city)
				&& Objects.equals(neighborhood, other.neighborhood) && Objects.equals(road, other.road)
				&& Objects.equals(state, other.state);
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", road=" + road + ", neighborhood=" + neighborhood + ", city="
				+ city + ", state=" + state + "]";
	}

	public Address(int addressId, String road, String neighborhood, String city, String state) {
		super();
		this.addressId = addressId;
		this.road = road;
		this.neighborhood = neighborhood;
		this.city = city;
		this.state = state;
	}

	public Address() {

	}
}
