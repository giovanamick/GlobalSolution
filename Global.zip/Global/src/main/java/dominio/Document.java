package dominio;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "document")
public class Document {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int documentId;

	@Column(length = 9, nullable = false)
	private String rg;

	@Column(length = 11, nullable = false)
	private String cpf;

	public int getDocumentId() {
		return documentId;
	}

	public void setDocumentId(int documentId) {
		this.documentId = documentId;
	}

	public String getRg() {
		return rg;
	}

	public void setRg(String rg) {
		this.rg = rg;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	@Override
	public int hashCode() {
		return Objects.hash(cpf, documentId, rg);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Document other = (Document) obj;
		return Objects.equals(cpf, other.cpf) && documentId == other.documentId && Objects.equals(rg, other.rg);
	}

	@Override
	public String toString() {
		return "Document [documentId=" + documentId + ", rg=" + rg + ", cpf=" + cpf + "]";
	}

	public Document(int documentId, String rg, String cpf) {
		super();
		this.documentId = documentId;
		this.rg = rg;
		this.cpf = cpf;
	}

	public Document() {

	}
}
