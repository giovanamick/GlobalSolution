package dominio;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "collect")
public class Collect {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int collectId;

	@Column(length = 20, nullable = false)
	private String collectType;

	@Column(name = "collect_amount", nullable = false)
	private int collectAmount;

	public int getCollectId() {
		return collectId;
	}

	public void setCollectId(int collectId) {
		this.collectId = collectId;
	}

	public String getCollectType() {
		return collectType;
	}

	public void setCollectType(String collectType) {
		this.collectType = collectType;
	}

	public int getCollectAmount() {
		return collectAmount;
	}

	public void setCollectAmount(int collectAmount) {
		this.collectAmount = collectAmount;
	}

	@Override
	public int hashCode() {
		return Objects.hash(collectAmount, collectId, collectType);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Collect other = (Collect) obj;
		return collectAmount == other.collectAmount && collectId == other.collectId
				&& Objects.equals(collectType, other.collectType);
	}

	@Override
	public String toString() {
		return "Collect [collectId=" + collectId + ", collectType=" + collectType + ", collectAmount=" + collectAmount
				+ "]";
	}

	public Collect(int collectId, String collectType, int collectAmount) {
		super();
		this.collectId = collectId;
		this.collectType = collectType;
		this.collectAmount = collectAmount;
	}

	public Collect() {

	}

}
