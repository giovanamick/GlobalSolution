package dominio;

import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "orderr")
public class Orderr {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int orderId;

	@Column(length = 50, nullable = false)
	private String orderContent;

	@Column(length = 50, nullable = false)
	private String orderSituation;

	@Column(length = 8, nullable = false)
	private String orderDate;

	@JoinColumn(name = "fk_client_id", nullable = false)
	private int clientId;

	@JoinColumn(name = "fk_organ_id", nullable = false)
	private int organId;

	@JoinColumn(name = "fk_collect_id", nullable = false)
	private int collectId;

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getOrderContent() {
		return orderContent;
	}

	public void setOrderContent(String orderContent) {
		this.orderContent = orderContent;
	}

	public String getOrderSituation() {
		return orderSituation;
	}

	public void setOrderSituation(String orderSituation) {
		this.orderSituation = orderSituation;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public int getClientId() {
		return clientId;
	}

	public void setClientId(int clientId) {
		this.clientId = clientId;
	}

	public int getOrganId() {
		return organId;
	}

	public void setOrganId(int organId) {
		this.organId = organId;
	}

	public int getCollectId() {
		return collectId;
	}

	public void setCollectId(int collectId) {
		this.collectId = collectId;
	}

	@Override
	public int hashCode() {
		return Objects.hash(clientId, collectId, orderContent, orderDate, orderId, orderSituation, organId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Orderr other = (Orderr) obj;
		return clientId == other.clientId && collectId == other.collectId
				&& Objects.equals(orderContent, other.orderContent) && Objects.equals(orderDate, other.orderDate)
				&& orderId == other.orderId && Objects.equals(orderSituation, other.orderSituation)
				&& organId == other.organId;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", orderContent=" + orderContent + ", orderSituation=" + orderSituation
				+ ", orderDate=" + orderDate + ", clientId=" + clientId + ", organId=" + organId + ", collectId="
				+ collectId + "]";
	}

	public Orderr(int orderId, String orderContent, String orderSituation, String orderDate, int clientId, int organId,
			int collectId) {
		super();
		this.orderId = orderId;
		this.orderContent = orderContent;
		this.orderSituation = orderSituation;
		this.orderDate = orderDate;
		this.clientId = clientId;
		this.organId = organId;
		this.collectId = collectId;
	}

	public Orderr() {

	}

}
