package dominio;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "vegetable_garden")
public class VegetableGarden {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int vegetableGardenId;

	@Column(name = "vegetable_garden_prod_amount", nullable = false)
	private int vegetableGardenProdAmount;

	@JoinColumn(name = "fk_vegetable_id", nullable = false)
	private int vegetableId;

	@JoinColumn(name = "fk_fruit_id", nullable = false)
	private int fruitId;

	public int getVegetableGardenId() {
		return vegetableGardenId;
	}

	public void setVegetableGardenId(int vegetableGardenId) {
		this.vegetableGardenId = vegetableGardenId;
	}

	public int getVegetableGardenProdAmount() {
		return vegetableGardenProdAmount;
	}

	public void setVegetableGardenProdAmount(int vegetableGardenProdAmount) {
		this.vegetableGardenProdAmount = vegetableGardenProdAmount;
	}

	public int getVegetableId() {
		return vegetableId;
	}

	public void setVegetableId(int vegetableId) {
		this.vegetableId = vegetableId;
	}

	public int getFruitId() {
		return fruitId;
	}

	public void setFruitId(int fruitId) {
		this.fruitId = fruitId;
	}

	@Override
	public int hashCode() {
		return Objects.hash(fruitId, vegetableGardenId, vegetableGardenProdAmount, vegetableId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VegetableGarden other = (VegetableGarden) obj;
		return fruitId == other.fruitId && vegetableGardenId == other.vegetableGardenId
				&& vegetableGardenProdAmount == other.vegetableGardenProdAmount && vegetableId == other.vegetableId;
	}

	@Override
	public String toString() {
		return "VegetableGarden [vegetableGardenId=" + vegetableGardenId + ", vegetableGardenProdAmount="
				+ vegetableGardenProdAmount + ", vegetableId=" + vegetableId + ", fruitId=" + fruitId + "]";
	}

	public VegetableGarden(int vegetableGardenId, int vegetableGardenProdAmount, int vegetableId, int fruitId) {
		super();
		this.vegetableGardenId = vegetableGardenId;
		this.vegetableGardenProdAmount = vegetableGardenProdAmount;
		this.vegetableId = vegetableId;
		this.fruitId = fruitId;
	}

	public VegetableGarden() {

	}
}
