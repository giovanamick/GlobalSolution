package dominio;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "userr")
public class Userr {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int userId;

	@Column(length = 50, nullable = false)
	private String name;

	@JoinColumn(name = "fk_contact_id", nullable = false)
	private int contactId;

	@JoinColumn(name = "fk_document_id", nullable = false)
	private int documentId;

	@JoinColumn(name = "fk_login_id", nullable = false)
	private int loginId;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getContactId() {
		return contactId;
	}

	public void setContactId(int contactId) {
		this.contactId = contactId;
	}

	public int getDocumentId() {
		return documentId;
	}

	public void setDocumentId(int documentId) {
		this.documentId = documentId;
	}

	public int getLoginId() {
		return loginId;
	}

	public void setLoginId(int loginId) {
		this.loginId = loginId;
	}

	@Override
	public int hashCode() {
		return Objects.hash(contactId, documentId, loginId, name, userId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Userr other = (Userr) obj;
		return contactId == other.contactId && documentId == other.documentId && loginId == other.loginId
				&& Objects.equals(name, other.name) && userId == other.userId;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", name=" + name + ", contactId=" + contactId + ", documentId=" + documentId
				+ ", loginId=" + loginId + "]";
	}

	public Userr(int userId, String name, int contactId, int documentId, int loginId) {
		super();
		this.userId = userId;
		this.name = name;
		this.contactId = contactId;
		this.documentId = documentId;
		this.loginId = loginId;
	}

	public Userr() {

	}

}
