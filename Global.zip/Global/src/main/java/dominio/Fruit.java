package dominio;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "fruit")
public class Fruit {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int fruitId;

	@Column(length = 50, nullable = false)
	private String fruitName;

	@JoinColumn(name = "fk_production_type_id", nullable = false)
	private int productionTypeId;

	@JoinColumn(name = "fk_production_quantity_id", nullable = false)
	private int productionQuantityId;

	public int getFruitId() {
		return fruitId;
	}

	public void setFruitId(int fruitId) {
		this.fruitId = fruitId;
	}

	public String getFruitName() {
		return fruitName;
	}

	public void setFruitName(String fruitName) {
		this.fruitName = fruitName;
	}

	public int getProductionTypeId() {
		return productionTypeId;
	}

	public void setProductionTypeId(int productionTypeId) {
		this.productionTypeId = productionTypeId;
	}

	public int getProductionQuantityId() {
		return productionQuantityId;
	}

	public void setProductionQuantityId(int productionQuantityId) {
		this.productionQuantityId = productionQuantityId;
	}

	@Override
	public int hashCode() {
		return Objects.hash(fruitId, fruitName, productionQuantityId, productionTypeId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Fruit other = (Fruit) obj;
		return fruitId == other.fruitId && Objects.equals(fruitName, other.fruitName)
				&& productionQuantityId == other.productionQuantityId && productionTypeId == other.productionTypeId;
	}

	@Override
	public String toString() {
		return "Fruit [fruitId=" + fruitId + ", fruitName=" + fruitName + ", productionTypeId=" + productionTypeId
				+ ", productionQuantityId=" + productionQuantityId + "]";
	}

	public Fruit(int fruitId, String fruitName, int productionTypeId, int productionQuantityId) {
		super();
		this.fruitId = fruitId;
		this.fruitName = fruitName;
		this.productionTypeId = productionTypeId;
		this.productionQuantityId = productionQuantityId;
	}

	public Fruit() {

	}
}
