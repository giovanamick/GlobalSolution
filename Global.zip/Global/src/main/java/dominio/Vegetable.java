package dominio;

import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "vegetable")
public class Vegetable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int vegetableId;

	@Column(length = 50, nullable = false)
	private String vegetableName;
	
	@JoinColumn(name = "fk_production_type_id", nullable = false)
	private int productionTypeId;
	
	@JoinColumn(name = "fk_production_quantity_id", nullable = false)
	private int productionQuantityId;

	public int getVegetableId() {
		return vegetableId;
	}

	public void setVegetableId(int vegetableId) {
		this.vegetableId = vegetableId;
	}

	public String getVegetableName() {
		return vegetableName;
	}

	public void setVegetableName(String vegetableName) {
		this.vegetableName = vegetableName;
	}

	public int getProductionTypeId() {
		return productionTypeId;
	}

	public void setProductionTypeId(int productionTypeId) {
		this.productionTypeId = productionTypeId;
	}

	public int getProductionQuantityId() {
		return productionQuantityId;
	}

	public void setProductionQuantityId(int productionQuantityId) {
		this.productionQuantityId = productionQuantityId;
	}

	public Vegetable(int vegetableId, String vegetableName, int productionTypeId, int productionQuantityId) {
		super();
		this.vegetableId = vegetableId;
		this.vegetableName = vegetableName;
		this.productionTypeId = productionTypeId;
		this.productionQuantityId = productionQuantityId;
	}

	@Override
	public String toString() {
		return "Vegetable [vegetableId=" + vegetableId + ", vegetableName=" + vegetableName + ", productionTypeId="
				+ productionTypeId + ", productionQuantityId=" + productionQuantityId + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(productionQuantityId, productionTypeId, vegetableId, vegetableName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vegetable other = (Vegetable) obj;
		return productionQuantityId == other.productionQuantityId && productionTypeId == other.productionTypeId
				&& vegetableId == other.vegetableId && Objects.equals(vegetableName, other.vegetableName);
	}

	public Vegetable() {

	}

}
