package dominio;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "production_quantity")
public class ProductionQuantity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int productionQuantityId;

	@Column(name = "quantity", nullable = false)
	private int quantity;

	public int getProductionQuantityId() {
		return productionQuantityId;
	}

	public void setProductionQuantityId(int productionQuantityId) {
		this.productionQuantityId = productionQuantityId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public int hashCode() {
		return Objects.hash(productionQuantityId, quantity);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductionQuantity other = (ProductionQuantity) obj;
		return productionQuantityId == other.productionQuantityId && quantity == other.quantity;
	}

	@Override
	public String toString() {
		return "ProductionQuantity [productionQuantityId=" + productionQuantityId + ", quantity=" + quantity + "]";
	}

	public ProductionQuantity(int productionQuantityId, int quantity) {
		super();
		this.productionQuantityId = productionQuantityId;
		this.quantity = quantity;
	}

	public ProductionQuantity() {

	}

}
