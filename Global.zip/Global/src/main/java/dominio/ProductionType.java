package dominio;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "production_type")
public class ProductionType {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int productionTypeId;

	@Column(length = 50, nullable = false)
	private String type;

	public int getProductionTypeId() {
		return productionTypeId;
	}

	public void setProductionTypeId(int productionTypeId) {
		this.productionTypeId = productionTypeId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public int hashCode() {
		return Objects.hash(productionTypeId, type);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductionType other = (ProductionType) obj;
		return productionTypeId == other.productionTypeId && Objects.equals(type, other.type);
	}

	@Override
	public String toString() {
		return "ProductionType [productionTypeId=" + productionTypeId + ", type=" + type + "]";
	}

	public ProductionType(int productionTypeId, String type) {
		super();
		this.productionTypeId = productionTypeId;
		this.type = type;
	}

	public ProductionType() {

	}
}
