package dominio;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "contact")
public class Contact {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int contactId;

	@Column(length = 15, nullable = false)
	private String phoneNumber;

	@Column(length = 9, nullable = false)
	private String celNumber;

	public int getContactId() {
		return contactId;
	}

	public void setContactId(int contactId) {
		this.contactId = contactId;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getCelNumber() {
		return celNumber;
	}

	public void setCelNumber(String celNumber) {
		this.celNumber = celNumber;
	}

	@Override
	public int hashCode() {
		return Objects.hash(celNumber, contactId, phoneNumber);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Contact other = (Contact) obj;
		return Objects.equals(celNumber, other.celNumber) && contactId == other.contactId
				&& Objects.equals(phoneNumber, other.phoneNumber);
	}

	@Override
	public String toString() {
		return "Contact [contactId=" + contactId + ", phoneNumber=" + phoneNumber + ", celNumber=" + celNumber + "]";
	}

	public Contact(int contactId, String phoneNumber, String celNumber) {
		super();
		this.contactId = contactId;
		this.phoneNumber = phoneNumber;
		this.celNumber = celNumber;
	}

	public Contact() {

	}
}
