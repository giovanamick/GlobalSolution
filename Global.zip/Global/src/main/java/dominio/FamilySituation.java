package dominio;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "family_situation")
public class FamilySituation {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int familyId;

	@Column(name = "family_size", nullable = false)
	private int familySize;

	@Column(name = "family_income", nullable = false)
	private int familyIncome;

	public int getFamilyId() {
		return familyId;
	}

	public void setFamilyId(int familyId) {
		this.familyId = familyId;
	}

	public int getFamilySize() {
		return familySize;
	}

	public void setFamilySize(int familySize) {
		this.familySize = familySize;
	}

	public int getFamilyIncome() {
		return familyIncome;
	}

	public void setFamilyIncome(int familyIncome) {
		this.familyIncome = familyIncome;
	}

	@Override
	public int hashCode() {
		return Objects.hash(familyId, familyIncome, familySize);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FamilySituation other = (FamilySituation) obj;
		return familyId == other.familyId && familyIncome == other.familyIncome && familySize == other.familySize;
	}

	@Override
	public String toString() {
		return "FamilySituation [familyId=" + familyId + ", familySize=" + familySize + ", familyIncome=" + familyIncome
				+ "]";
	}

	public FamilySituation(int familyId, int familySize, int familyIncome) {
		super();
		this.familyId = familyId;
		this.familySize = familySize;
		this.familyIncome = familyIncome;
	}

	public FamilySituation() {

	}
}
