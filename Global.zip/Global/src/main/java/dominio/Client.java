package dominio;

import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "client")
public class Client {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int clientId;

	@JoinColumn(name = "fk_address_id", nullable = false)
	private int addressId;

	@JoinColumn(name = "fk_user_id", nullable = false)
	private int userId;

	@JoinColumn(name = "fk_family_id", nullable = false)
	private int familyId;

	public int getClientId() {
		return clientId;
	}

	public void setClientId(int clientId) {
		this.clientId = clientId;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getFamilyId() {
		return familyId;
	}

	public void setFamilyId(int familyId) {
		this.familyId = familyId;
	}

	@Override
	public int hashCode() {
		return Objects.hash(addressId, clientId, familyId, userId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Client other = (Client) obj;
		return addressId == other.addressId && clientId == other.clientId && familyId == other.familyId
				&& userId == other.userId;
	}

	@Override
	public String toString() {
		return "Client [clienteId=" + clientId + ", addressId=" + addressId + ", userId=" + userId + ", familyId="
				+ familyId + "]";
	}

	public Client(int clienteId, int addressId, int userId, int familyId) {
		super();
		this.clientId = clienteId;
		this.addressId = addressId;
		this.userId = userId;
		this.familyId = familyId;
	}

	public Client() {

	}
}
