package dominio;

import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "head_of_the_organization")
public class HeadOfTheOrganization {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int hotoId;

	@JoinColumn(name = "fk_address_id", nullable = false)
	private int addressId;

	@JoinColumn(name = "fk_user_id", nullable = false)
	private int userId;

	public int getHotoId() {
		return hotoId;
	}

	public void setHotoId(int hotoId) {
		this.hotoId = hotoId;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	@Override
	public int hashCode() {
		return Objects.hash(addressId, hotoId, userId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HeadOfTheOrganization other = (HeadOfTheOrganization) obj;
		return addressId == other.addressId && hotoId == other.hotoId && userId == other.userId;
	}

	@Override
	public String toString() {
		return "HeadOfTheOrganization [hotoId=" + hotoId + ", addressId=" + addressId + ", userId=" + userId + "]";
	}

	public HeadOfTheOrganization(int hotoId, int addressId, int userId) {
		super();
		this.hotoId = hotoId;
		this.addressId = addressId;
		this.userId = userId;
	}

	public HeadOfTheOrganization() {

	}
}
