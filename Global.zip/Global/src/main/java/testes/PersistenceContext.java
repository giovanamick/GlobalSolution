package testes;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import dominio.Vegetable;

public class PersistenceContext {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Global");
		EntityManager em = emf.createEntityManager();

		em.getTransaction().begin();
		
		Vegetable vegetable1 = em.find(Vegetable.class, 2);
		System.out.println("Searched for vegetable for the first time...");
		Vegetable vegetable2 = em.find(Vegetable.class, 2);
		System.out.println("Searched for vegetable for the second time...");
		System.out.println("Even vegetables? " + (vegetable1 == vegetable2));

		em.getTransaction().commit();

		System.out.println("Ready");
		em.close();
		emf.close();

	}

}
