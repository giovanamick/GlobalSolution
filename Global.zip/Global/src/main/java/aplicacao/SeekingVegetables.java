package aplicacao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import dominio.Vegetable;

public class SeekingVegetables {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Global");
		EntityManager em = emf.createEntityManager();

		Vegetable vegetable = em.find(Vegetable.class, 2);
		System.out.println("Vegetable Code: " + vegetable.getVegetableId() + " and " + vegetable.getVegetableName());

		System.out.println("Ready");
		em.close();
		emf.close();

	}

}
