package aplicacao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import dominio.Vegetable;

public class ConsultingVegetables {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Global");
		EntityManager em = emf.createEntityManager();

		Vegetable vegetable = em.find(Vegetable.class, 3);
		System.out.println(vegetable.getVegetableName());

		System.out.println("Ready");
		em.close();
		emf.close();

	}

}
