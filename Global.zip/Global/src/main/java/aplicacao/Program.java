package aplicacao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import dominio.Address;
import dominio.Contact;
import dominio.Document;
import dominio.FamilySituation;
import dominio.Fruit;
import dominio.Login;
import dominio.Orderr;
import dominio.Organ;
import dominio.ProductionQuantity;
import dominio.ProductionType;
import dominio.Userr;
import dominio.Vegetable;
import dominio.VegetableGarden;

public class Program {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Global");
		EntityManager em = emf.createEntityManager();

		em.getTransaction().begin();

		Login login1 = new Login();
		login1.setEmail("giovana@email.com");
		login1.setPassword("1234");
		
		Login login2 = new Login();
		login2.setEmail("gabriel@email.com");
		login2.setPassword("5678");
		
		Contact contact1 = new Contact();
		contact1.setPhoneNumber("245621856");
		contact1.setCelNumber("973204267");
		
		Contact contact2 = new Contact();
		contact2.setPhoneNumber("245624567");
		contact2.setCelNumber("973202357");

		Document document1 = new Document();
		document1.setRg("501963472");
		document1.setCpf("52580330838");
		
		Document document2 = new Document();
		document2.setRg("501963479");
		document2.setCpf("52580330828");

		Address address1 = new Address();
		address1.setRoad("Lisboa, 139");
		address1.setNeighborhood("Parque Continental 2");
		address1.setCity("Guarulhos");
		address1.setState("SP");
		
		Address address2 = new Address();
		address2.setRoad("Gumercindo De Paula, 253");
		address2.setNeighborhood("Jardim Monte Alegre");
		address2.setCity("São Paulo");
		address2.setState("SP");

		FamilySituation familysituation1 = new FamilySituation();
		familysituation1.setFamilySize(4);
		familysituation1.setFamilyIncome(3000);
		
		FamilySituation familysituation2 = new FamilySituation();
		familysituation2.setFamilySize(4);
		familysituation2.setFamilyIncome(4000);
		
		ProductionType productiontype1 = new ProductionType();
		productiontype1.setType("Fruit");
		
		ProductionType productiontype2 = new ProductionType();
		productiontype2.setType("Vegetable");
		
		ProductionQuantity productionquantity1 = new ProductionQuantity();
		productionquantity1.setQuantity(1000);
		
		ProductionQuantity productionquantity2 = new ProductionQuantity();
		productionquantity2.setQuantity(5000);
				
		Fruit fruit1 = new Fruit();
		fruit1.setFruitName("Tomato");
		
		Fruit fruit2 = new Fruit();
		fruit2.setFruitName("Apple");

		Vegetable vegetable1 = new Vegetable();
		vegetable1.setVegetableName("Carrot");
		
		Vegetable vegetable2 = new Vegetable();
		vegetable2.setVegetableName("Potato");

		VegetableGarden vegetablegarden1 = new VegetableGarden();
		vegetablegarden1.setVegetableGardenProdAmount(1000);
		
		VegetableGarden vegetablegarden2 = new VegetableGarden();
		vegetablegarden2.setVegetableGardenProdAmount(5000);
		
		Organ organ1 = new Organ();
		organ1.setOrganName("Prefeitura de Foz do Iguacu");
		
		Organ organ2 = new Organ();
		organ2.setOrganName("Prefeitura de Paraisopoles");
		
		Orderr orderr1 = new Orderr();
		orderr1.setOrderContent("2 potatoes, 3 carrots and 4 onions");
		orderr1.setOrderSituation("open");
		orderr1.setOrderDate("01062023");
		
		Orderr orderr2 = new Orderr();
		orderr2.setOrderContent("7 potatoes, 7 carrots and 2 onions");
		orderr2.setOrderSituation("closed");
		orderr2.setOrderDate("27052023");

		Userr userr1 = new Userr();
		userr1.setName("Giovana Santos Viana");
		
		Userr userr2 = new Userr();
		userr2.setName("Gabriel Lerri De Almeida Rodrigues");

		em.persist(address1);
		em.persist(address2);
		em.persist(contact1);
		em.persist(contact2);
		em.persist(document1);
		em.persist(document2);
		em.persist(familysituation1);
		em.persist(familysituation2);
		em.persist(fruit1);
		em.persist(fruit2);
		em.persist(login1);
		em.persist(login2);
		em.persist(orderr1);
		em.persist(orderr2);
		em.persist(organ1);
		em.persist(organ2);
		em.persist(productionquantity1);
		em.persist(productionquantity2);
		em.persist(productiontype1);
		em.persist(productiontype2);
		em.persist(userr1);
		em.persist(userr2);
		em.persist(vegetable1);
		em.persist(vegetable2);
		em.persist(vegetablegarden1);
		em.persist(vegetablegarden2);

		em.getTransaction().commit();

		System.out.println("Ready");
		em.close();
		emf.close();

	}
}
