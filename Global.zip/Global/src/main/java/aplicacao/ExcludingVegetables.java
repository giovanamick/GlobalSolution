package aplicacao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import dominio.Vegetable;

public class ExcludingVegetables {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Global");
		EntityManager em = emf.createEntityManager();

		em.getTransaction().begin();

		Vegetable vegetable = em.find(Vegetable.class, 1);
		em.remove(vegetable);

		em.getTransaction().commit();

		System.out.println("Ready");
		em.close();
		emf.close();

	}

}
