package aplicacao;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import dominio.Vegetable;
import java.util.List;

public class VegetableSearch {

    public List<Vegetable> searchByVegetableName(EntityManager entityManager, String vegetableName) {    
        TypedQuery<Vegetable> query = entityManager.createQuery("SELECT v FROM Vegetable v WHERE v.name = :vegetableName", Vegetable.class);
        query.setParameter("vegetableName", vegetableName);
        return query.getResultList();
    }

}
