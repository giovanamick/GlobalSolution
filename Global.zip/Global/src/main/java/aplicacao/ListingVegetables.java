package aplicacao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import dominio.Vegetable;
import java.util.List;

public class ListingVegetables {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Global");
		EntityManager em = emf.createEntityManager();

		TypedQuery<Vegetable> query = em.createQuery("SELECT v FROM Vegetable v", Vegetable.class);

		List<Vegetable> vegetables = query.getResultList();
		for (Vegetable vegetable : vegetables) {
			System.out.println(vegetable.getVegetableId() + " - " + vegetable.getVegetableName());
		}

		System.out.println("Ready");
		em.close();
		emf.close();

	}
}
