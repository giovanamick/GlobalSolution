package aplicacao;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import dominio.Vegetable;
import java.util.List;

public class VegetableDelete {

    public void deleteVegetablesByName(EntityManager entityManager, String vegetableName) {
        entityManager.getTransaction().begin();
        TypedQuery<Vegetable> query = entityManager.createQuery("SELECT v FROM Vegetable v WHERE v.name = :vegetableName", Vegetable.class);
        query.setParameter("vegetableName", vegetableName);
        List<Vegetable> vegetablesToDelete = query.getResultList();
        for (Vegetable vegetable : vegetablesToDelete) {
            entityManager.remove(vegetable);
        }
        entityManager.getTransaction().commit();
    }

}
